#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CANT 3

typedef struct{
    int dia,mes,anio;
}eFecha;

typedef struct{
    char nombre[21];
    int legajo;
    float sueldo;
    char sexo;
    eFecha fnac;
}eEmpleado;

void alta(eEmpleado[],int);
void ordenarPorSueldo(eEmpleado[],int);

int main()
{
    eEmpleado plantel[CANT];

    return 0;
}

void alta(eEmpleado empleado[],int tam){
    int i;
    for(i=0;i<tam;i++){
    printf("Ingrese nombre: ");
    fflush(stdin);
    scanf("%[^\n]",empleado[i].nombre);
    printf("Legajo: ");
    scanf("%d",empleado[i].legajo)
    printf("Sueldo: ");
    scanf("%f",empleado[i].sueldo);
    printf("Sexo: ");
    scanf("%c",empleado[i].sexo);
    printf("Fecha de nacimiento: ");

    }
}

void ordenarPorSueldo(eEmpleado empleado[],int tam){
    int i,j;
    eEmpleado aux;

    for(i=0;i<tam-1;++){
        for(j=i+1;j<tam;j++){
            if(empleado[i].sueldo<empleado[j].sueldo){
               aux=empleado[i];
               empleado[i]=empleado[j];
               empleado[j]=aux;
            }
            else if(empleado[i].sueldo==empleado[j].sueldo){
                if(strcmp(empleado[i].nombre,empleado[j].nombre)>0){
                    aux=empleado[i];
                    empleado[i]=empleado[j];
                    empleado[j]=aux;
                }
            }
        }
    }
}
